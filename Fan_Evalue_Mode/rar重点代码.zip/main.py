import network
import uasyncio as asyncio
from machine import UART
from microdot_asyncio import Microdot, Response

# ===== UART 配置 =====
uart = UART(2, baudrate=9600, tx=17, rx=16)  # 别忘了：TX=17，RX=16
uart.init(9600, bits=8, parity=None, stop=1)

# ===== 启动 WiFi AP =====
ap = network.WLAN(network.AP_IF)
ap.active(True)
ap.config(essid='ESP32-FAN', password='12345678')
ap.ifconfig(('192.168.4.1', '255.255.255.0', '192.168.4.1', '8.8.8.8'))
print("AP started at:", ap.ifconfig())

# ===== 初始化环形缓冲区 =====
uart_buffer = b""         # 原始缓冲区
parsed_packets = []       # 解析出的合法数据包

# ===== 异步 UART 接收函数 =====
async def read_uart():
    global uart_buffer, parsed_packets
    while True:
        if uart.any():
            uart_buffer += uart.read()

            # 尝试提取完整数据包
            while len(uart_buffer) >= 4:
                if uart_buffer[0] == 0x55 and uart_buffer[3] == 0xFF:
                    # 提取合法数据包
                    packet = uart_buffer[0:4]
                    uart_buffer = uart_buffer[4:]  # 移除已处理部分

                    parsed_packets.append(packet)
                    print("收到合法数据包：", list(packet))
                else:
                    # 若首字节不是包头，则丢弃一个字节，继续寻找
                    uart_buffer = uart_buffer[1:]
        await asyncio.sleep(0.01)

# ===== 简易 Web Server =====
Response.default_content_type = 'text/plain'
app = Microdot()

@app.route('/')
async def index(request):
    return 'ESP32 Fan Server Running.'

# ===== 发送合法数据包给 APP =====
@app.route('/data')
async def get_data(request):
    global parsed_packets
    if parsed_packets:
        pkt = parsed_packets.pop(0)
        # 返回格式为 JSON 友好样式，例如：{"cmd": "A", "val": 0}
        return f'{chr(pkt[1])},{pkt[2]}'
    else:
        return 'NO DATA'

# ===== 控制接口：接收来自 APP 的命令并转发 =====
@app.route('/control/<cmd>')
async def control_cmd(request, cmd):
    valid_cmds = ['R', 'S', 'F', 'X']
    cmd = cmd.upper()
    if cmd in valid_cmds:
        uart.write(cmd.encode())
        print(f"APP 发来控制指令：{cmd}")
        return f'OK: Sent command {cmd}'
    else:
        return 'ERROR: Invalid command'

# ===== 主程序入口 =====
async def main():
    print("启动服务中...")
    asyncio.create_task(read_uart())
    await app.start_server(host='0.0.0.0', port=80)

asyncio.run(main())
