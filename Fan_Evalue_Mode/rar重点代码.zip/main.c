/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "iwdg.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "oled.h"
#include "oledfont.h"

#include "NanoEdgeAI.h"
#include "knowledge.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define ADC_SAMPLES 512
#define ADC_CHANNELS 3
#define ADC_BUFFER_SIZE (ADC_SAMPLES * ADC_CHANNELS)
#define RX_BUFFER_SIZE 64 // USART3 DMA缓冲大小
#define SAMPLE_NUM 3 // 采样取平均的次数

uint16_t adc_buffer[ADC_BUFFER_SIZE];
uint8_t rx_buffer[RX_BUFFER_SIZE]; // USART3 DMA缓冲区
volatile uint8_t data_ready_flag = 0;
static uint8_t model_initialized = 0;
uint8_t similarity = 0; // 相似度

volatile uint8_t run_flag = 1;  // 是否运行模型，默认
volatile uint8_t fan_state = 1; // 风机状态（1=开，0=关）

float similarity_buffer[SAMPLE_NUM]; // 多次的相似度存到一个数组里面，留着判断
uint8_t sample_index = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Start_ADC_DMA_Sampling(void);
void Stop_ADC_DMA_Sampling(void);
void Run_NanoEdge_Inference(void);
void Send_ESP32_data(void);
void ProcessCommand(uint8_t *data, uint16_t len);
void HAL_UART_IDLECallback(UART_HandleTypeDef *huart);
void Send_to_ESP32_Lize_Data(void);
void OLED_ShowStatusAndSimilarity(void);
float Similarity_Standard(float *buffer, uint8_t len);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int   __io_putchar(int ch)
{
        HAL_UART_Transmit(&huart4,(uint8_t *) &ch, 1, 1000);
        return ch;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_USART3_UART_Init();
  MX_I2C3_Init();
  MX_UART4_Init();
  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */

  OLED_Init();
  OLED_Clear();
  // 开启空闲中断 + DMA接收
  __HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);
  HAL_UART_Receive_DMA(&huart3, rx_buffer, RX_BUFFER_SIZE);

  Start_ADC_DMA_Sampling(); // 初始化时就打开，TIM3作为ADC1的触发源，不受CPU直接控制
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  HAL_IWDG_Refresh(&hiwdg); //喂狗
	  if (__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST))
	  {
	      // 看门狗复位
	      __HAL_RCC_CLEAR_RESET_FLAGS();
	      printf("Reset! WatchDog! ");
	  }
	  else
	  {
		  printf("not reset!");
	  }
	  // LED关闭，表示系统空闲/开始准备工作
	  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

	  if (run_flag) //  系统运行标志位控制整个推理流程
	  {
		  if (data_ready_flag) // 判断ADC采集是否完成
		  {
		      data_ready_flag = 0;
		      Stop_ADC_DMA_Sampling();

		      for (int i = 0; i < SAMPLE_NUM; i++) {
		          Run_NanoEdge_Inference();  // 原函数不动
		          similarity_buffer[i] = similarity;  // 保存每次的结果
		          HAL_Delay(50);  // 可以短一点，防止太快导致采样一样
		      }

		      // 计算“标准”值，例如去极值后平均
		      similarity = (uint8_t)Similarity_Standard(similarity_buffer, SAMPLE_NUM);

		      Send_to_ESP32_Lize_Data();  // 发送处理后的 similarity
		      OLED_ShowStatusAndSimilarity();

		      HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);  // 表示推理完成
		  }



	       HAL_Delay(1000); // 模型执行间隔，你可以调小一点更灵敏
	       Start_ADC_DMA_Sampling();  // 开始下一轮采样
	  }
	  else
	  {
	      // 如果 run_flag == 0，则啥都不干，系统进入待机状态
	      HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
// NanoEdgeAI给的例程 用于填充数据
void fill_buffer(float input_buffer[]) {
    for (int i = 0; i < ADC_SAMPLES; i++) {
        input_buffer[i * 3 + 0] = adc_buffer[i * 3 + 0] / 4095.0f; // X
        input_buffer[i * 3 + 1] = adc_buffer[i * 3 + 1] / 4095.0f; // Y
        input_buffer[i * 3 + 2] = adc_buffer[i * 3 + 2] / 4095.0f; // Z
    }


    for (int i = 0; i < 5; i++) {
        printf("X[%d]: %.3f\tY[%d]: %.3f\tZ[%d]: %.3f\r\n",
               i, input_buffer[i * 3 + 0],
               i, input_buffer[i * 3 + 1],
               i, input_buffer[i * 3 + 2]);
    }
}

// ADC回调函数
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if (hadc->Instance == ADC1) {
        data_ready_flag = 1;
    }
}

// ADC+DMA开始采集
void Start_ADC_DMA_Sampling(void)
{
    HAL_TIM_Base_Start(&htim3);
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buffer, ADC_BUFFER_SIZE);
}

// ADC+DMA停止采集
void Stop_ADC_DMA_Sampling(void)
{
    HAL_ADC_Stop_DMA(&hadc1);
    HAL_TIM_Base_Stop(&htim3);
}

// 静态评估模式
void Run_NanoEdge_Inference(void)
{
    if (!model_initialized)
    {
        enum neai_state error_code = neai_anomalydetection_init();
        if (error_code != NEAI_OK) {
            printf("NanoEdge init failed!\r\n");
            Error_Handler();
        }


        error_code = neai_anomalydetection_knowledge(knowledge);
        if (error_code != NEAI_OK)
        {
            printf("Knowledge load failed!\r\n");
            Error_Handler();
           }
        model_initialized = 1;
    }

    float input_user_buffer[ADC_SAMPLES * ADC_CHANNELS]; // 3*512
    fill_buffer(input_user_buffer);


    neai_anomalydetection_detect(input_user_buffer, &similarity);
    printf("Similarity: %d\r\n", similarity);
}

/**
 * @brief 用于运行 NanoEdge 的学习模式（动态在线学习正常数据）
 * @note  本函数假设 ADC 已经采集好 512×3 = 1536 点数据在 adc_buffer 中，
 *        会把数据归一化后调用 NanoEdge 的学习接口。
 * @note  每调用一次就学习一次，最多建议调用 20 次。
 * @note  适合用于设备上线后的“自学习阶段”，再切入推理检测。
 */
void Run_NanoEdge_Learning(void)
{
    static uint16_t learn_counter = 0;


    if (!model_initialized)
    {
        enum neai_state error_code = neai_anomalydetection_init();
        if (error_code != NEAI_OK) {
            printf("NanoEdge init failed!\r\n");
            Error_Handler();
        }

        printf("NanoEdge learning mode initialized.\r\n");
        model_initialized = 1;
    }


    float input_user_buffer[ADC_SAMPLES * ADC_CHANNELS];
    fill_buffer(input_user_buffer);


    enum neai_state learn_status = neai_anomalydetection_learn(input_user_buffer);

    printf("Learning round [%02d/20] - status: %d\r\n", learn_counter + 1, learn_status);

    learn_counter++;

    if (learn_counter >= 20) {
        printf("Learning phase complete. Ready for detection.\r\n");
    }
}

// 指令处理函数（仅处理 'R', 'S', 'F', 'X'）
void ProcessCommand(uint8_t *data, uint16_t len)
{
    for (uint16_t i = 0; i < len; i++) {
        switch (data[i]) {
            case 'R': //HAL_GPIO_WritePin(Fan_Key_GPIO_Port, Fan_Key_Pin, GPIO_PIN_SET);
            	run_flag = 1;
            	break;  // 运行
            case 'S': //HAL_GPIO_WritePin(Fan_Key_GPIO_Port, Fan_Key_Pin, GPIO_PIN_RESET);
            	run_flag = 0;
            	break; // 暂停
            case 'F': HAL_GPIO_WritePin(Mode_Run_Test_GPIO_Port, Mode_Run_Test_Pin, GPIO_PIN_SET); break;  // 风机开
            case 'X': HAL_GPIO_WritePin(Mode_Run_Test_GPIO_Port, Mode_Run_Test_Pin, GPIO_PIN_RESET); break; // 风机关
            default: break;
        }
    }
}

// USART3 空闲中断回调函数：用于接收 ESP32 发送的指令
void HAL_UART_IDLECallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3)
    {
        __HAL_UART_CLEAR_IDLEFLAG(&huart3); // 清除空闲中断标志

        // 计算接收到的数据长度（RX_BUFFER_SIZE - DMA当前未传输的长度）
        uint16_t data_len = RX_BUFFER_SIZE - __HAL_DMA_GET_COUNTER(huart->hdmarx);

        // 调用指令处理函数
        ProcessCommand(rx_buffer, data_len);

        // 重新启动 DMA 接收
        HAL_UART_Receive_DMA(&huart3, rx_buffer, RX_BUFFER_SIZE);
    }
}

void Send_to_ESP32_Lize_Data(void)
{
	if (similarity >= 90)
	{
		SendPacketToESP32('A', similarity);
	}
	else if(similarity>80 && similarity<90)
	{
		SendPacketToESP32('E', similarity);
	}
	else if (similarity < 80)
	{
		SendPacketToESP32('D', similarity);
	}
}

void OLED_ShowStatusAndSimilarity(void)
{
    uint8_t status_index = 0;

    if (similarity >= 90)
    {
        status_index = 0; // 正常
    }
    else if (similarity >= 80 && similarity < 90)
    {
        status_index = 2; // 警告
    }
    else
    {
        status_index = 7; // 异常
    }

    OLED_Clear();

    // 第一行 状态
    OLED_ShowCHinese(0, 0, 9, 0);  // "状"
    OLED_ShowCHinese(16, 0, 10, 0);  // "态"
    OLED_ShowChar(32, 0, ':', 16, 0);
    OLED_ShowCHinese(48, 0, status_index, 0);
    OLED_ShowCHinese(64, 0, status_index + 1, 0);

    // 第二行 相似度: XX%
    OLED_ShowCHinese(0, 2, 4, 0);  // "相"
    OLED_ShowCHinese(16, 2, 5, 0); // "似"
    OLED_ShowCHinese(32, 2, 6, 0); // "度"
    OLED_ShowChar(48, 2, ':', 16, 0);
    OLED_ShowNum(56, 2, similarity, 3, 16, 0);
    OLED_ShowChar(80, 2, '%', 16, 0);
}

float Similarity_Standard(float *buffer, uint8_t len)
{
    float sum = 0;
    float min = buffer[0];
    float max = buffer[0];

    for (int i = 0; i < len; i++) {
        float val = buffer[i];
        sum += val;
        if (val < min) min = val;
        if (val > max) max = val;
    }

    // 防止除以 0（万一len <= 2）
    if (len <= 2) return sum / len;

    return (sum - min - max) / (len - 2);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
	  printf("error!!!!!!!!!");
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
