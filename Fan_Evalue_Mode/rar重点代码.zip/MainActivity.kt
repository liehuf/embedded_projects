package com.example.fan_evaluator

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.fan_evaluator.ui.theme.Fan_EvaluatorTheme
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// 数据状态类
data class FanStatus(
    val rawData: String = "",  // 原始数据
    val hasData: Boolean = false,  // 是否已收到数据
    val status: String = "",  // 状态（正常/警告/异常）
    val similarity: Int = 0,  // 相似度
    val suggestion: String = ""  // 建议
)

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        initializeApp()
    }

    private fun initializeApp() {
        setContent {
            Fan_EvaluatorTheme {
                MainScreen(client)
            }
        }
    }
}

@Composable
fun MainScreen(client: OkHttpClient) {
    val context = LocalContext.current
    var fanStatus by remember { mutableStateOf(FanStatus()) }
    var commandList by remember { mutableStateOf(listOf<String>()) }
    val scrollState = rememberScrollState()
    val commandScrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    var isConnected by remember { mutableStateOf(false) }
    var isAutoConnect by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf("") }
    var hasShownConnected by remember { mutableStateOf(false) }
    var hasShownError by remember { mutableStateOf(false) }

    // 自动滚动到底部
    LaunchedEffect(fanStatus) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    LaunchedEffect(commandList) {
        commandScrollState.animateScrollTo(commandScrollState.maxValue)
    }

    // 更新时间
    LaunchedEffect(Unit) {
        while (true) {
            val now = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            currentTime = now.format(formatter)
            delay(1000)
        }
    }

    // 定时刷新数据
    LaunchedEffect(isAutoConnect) {
        while (isAutoConnect) {
            coroutineScope.launch {
                try {
                    val newData = fetchData(client)
                    isConnected = newData != null
                    if (newData != null) {
                        hasShownError = false
                        // 解析数据
                        val parts = newData.split(",")
                        if (parts.size >= 2) {
                            val status = when (parts[0]) {
                                "A" -> "正常"
                                "E" -> "警告"
                                "D" -> "异常"
                                else -> "未知"
                            }
                            val similarity = parts[1].toIntOrNull() ?: 0
                            val suggestion = when (parts[0]) {
                                "A" -> "系统运行正常，请继续保持"
                                "E" -> "系统出现警告，建议检查设备状态"
                                "D" -> "系统异常，请立即检查并处理"
                                else -> "无法确定系统状态"
                            }
                            withContext(Dispatchers.Main) {
                                fanStatus = FanStatus(
                                    rawData = newData,
                                    hasData = true,
                                    status = status,
                                    similarity = similarity,
                                    suggestion = suggestion
                                )
                                // 只在收到有意义的数据时更新命令状态
                                if (parts[0] in listOf("A", "E", "D")) {
                                    commandList = commandList + "收到数据: $newData"
                                }
                            }
                        }
                    } else {
                        // 只在未显示过错误时显示错误信息
                        if (!hasShownError) {
                            commandList = commandList + "未检测到数据，请检查连接"
                            hasShownError = true
                        }
                        // 连接失败时自动关闭开关
                        isAutoConnect = false
                        hasShownConnected = false
                    }
                } catch (e: Exception) {
                    Log.e("Network", "定时刷新错误: ${e.message}", e)
                    isConnected = false
                    // 只在未显示过错误时显示错误信息
                    if (!hasShownError) {
                        commandList = commandList + "连接错误: ${e.message}"
                        hasShownError = true
                    }
                    // 发生错误时自动关闭开关
                    isAutoConnect = false
                    hasShownConnected = false
                }
            }
            delay(500) // 每500毫秒刷新一次
        }
    }

    // 监听开关状态变化
    LaunchedEffect(isAutoConnect) {
        if (!isAutoConnect) {
            hasShownConnected = false
            hasShownError = false
            isConnected = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 标题
        Text(
            text = "风机监测助手",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(bottom = 16.dp)
                .fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        // 连接状态和控制区域
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isConnected) "连接状态：已连接" else "连接状态：未连接",
                color = if (isConnected) Color(0xFF4CAF50) else Color(0xFFF44336),
                fontSize = 16.sp
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "WIFI",
                    fontSize = 16.sp,
                    color = Color.Gray
                )
                Switch(
                    checked = isAutoConnect,
                    onCheckedChange = { 
                        isAutoConnect = it
                        commandList = commandList + if (it) "开始自动连接" else "断开连接"
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF4CAF50),
                        checkedTrackColor = Color(0xFF81C784),
                        uncheckedThumbColor = Color(0xFFF44336),
                        uncheckedTrackColor = Color(0xFFE57373)
                    )
                )
            }
        }

        // 数据区（上半部分）
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(bottom = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = "当前时间：$currentTime",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "系统状态：${fanStatus.status}",
                        fontSize = 16.sp,
                        color = when (fanStatus.status) {
                            "正常" -> Color(0xFF4CAF50)
                            "警告" -> Color(0xFFFFA000)
                            "异常" -> Color(0xFFF44336)
                            else -> Color.Black
                        },
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "相似度：${fanStatus.similarity}%",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "建议：${fanStatus.suggestion}",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                
                // 清除按钮
                IconButton(
                    onClick = { 
                        fanStatus = FanStatus()
                    },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "清除数据",
                        tint = Color.Gray
                    )
                }
            }
        }

        // 命令状态区（下半部分）
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                        .verticalScroll(commandScrollState)
                ) {
                    commandList.forEach { text ->
                        Text(
                            text = text,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
                
                // 清除按钮
                IconButton(
                    onClick = { 
                        commandList = emptyList()
                    },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "清除命令",
                        tint = Color.Gray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 系统控制区域
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "系统控制",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ControlButton("启动系统(R)", "R", client, context) { cmd ->
                    commandList = commandList + "已发送启动系统命令"
                }
                ControlButton("停止系统(S)", "S", client, context) { cmd ->
                    commandList = commandList + "已发送停止系统命令"
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 风机控制区域
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "风机控制",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ControlButton("打开风机(F)", "F", client, context) { cmd ->
                    commandList = commandList + "已发送打开风机命令"
                }
                ControlButton("关闭风机(X)", "X", client, context) { cmd ->
                    commandList = commandList + "已发送关闭风机命令"
                }
            }
        }
    }
}

@Composable
fun ControlButton(
    text: String,
    cmd: String,
    client: OkHttpClient,
    context: android.content.Context,
    onSend: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    Button(
        onClick = {
            coroutineScope.launch {
                val success = sendCommand(client, cmd)
                if (success) {
                    Toast.makeText(context, "命令 $cmd 已发送", Toast.LENGTH_SHORT).show()
                    onSend(cmd)
                } else {
                    Toast.makeText(context, "无法连接ESP32", Toast.LENGTH_SHORT).show()
                }
            }
        },
        modifier = Modifier.padding(horizontal = 8.dp)
    ) {
        Text(text)
    }
}

// 拉取数据
suspend fun fetchData(client: OkHttpClient): String? = withContext(Dispatchers.IO) {
    // 首先测试连接
    val testRequest = Request.Builder()
        .url("http://192.168.4.1/")
        .cacheControl(okhttp3.CacheControl.FORCE_NETWORK)
        .build()
    
    try {
        Log.d("Network", "开始测试连接...")
        // 测试连接
        client.newCall(testRequest).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e("Network", "测试连接失败: HTTP ${response.code} - ${response.message}")
                return@withContext null
            }
            Log.d("Network", "测试连接成功: HTTP ${response.code}")
        }
        
        Log.d("Network", "开始获取数据...")
        // 如果连接测试成功，获取数据
        val request = Request.Builder()
            .url("http://192.168.4.1/data")
            .cacheControl(okhttp3.CacheControl.FORCE_NETWORK)
            .build()
        
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e("Network", "获取数据失败: HTTP ${response.code} - ${response.message}")
                return@withContext null
            }
            val body = response.body?.string()
            if (body.isNullOrEmpty()) {
                Log.e("Network", "获取到的数据为空")
                return@withContext null
            }
            Log.d("Network", "成功获取数据: $body")
            return@withContext body
        }
    } catch (e: IOException) {
        Log.e("Network", "网络IO错误: ${e.message}", e)
        Log.e("Network", "错误类型: ${e.javaClass.simpleName}")
        Log.e("Network", "错误堆栈: ${e.stackTraceToString()}")
        return@withContext null
    } catch (e: Exception) {
        Log.e("Network", "未知错误: ${e.message}", e)
        Log.e("Network", "错误类型: ${e.javaClass.simpleName}")
        Log.e("Network", "错误堆栈: ${e.stackTraceToString()}")
        return@withContext null
    }
}

// 发送控制指令
suspend fun sendCommand(client: OkHttpClient, cmd: String): Boolean = withContext(Dispatchers.IO) {
    val url = "http://192.168.4.1/control/$cmd"
    val request = Request.Builder().url(url).build()
    try {
        client.newCall(request).execute().use { response ->
            return@withContext response.isSuccessful
        }
    } catch (e: IOException) {
        return@withContext false
    }
}